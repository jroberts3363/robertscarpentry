<!DOCTYPE HTML>
<head>
	<title>Simple Contact Form</title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>

<body>


		<h1>Your message has been sent!</h1><br />
		<p>Thank you for your email. I'll get back to you shortly.</p> <br />
		<p>Best regards,</p> <br />
		<p>Ian Roberts</p>


</body>
</html>